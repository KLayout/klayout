#-------------------------------------------------------------------------
# File: MacPortsUser-ReadMeFirst.txt
#                              in macbuild/Resources/script-bundle-P.zip
#
# Last modified: 2022-10-10
#-------------------------------------------------------------------------

This folder contains the "KLayoutPorts.app" script bundle and some sample icon files.


[1] MacPorts setup
    First, you must set up the MacPorts environment to use this package.
    Referring to https://www.macports.org/install.php, follow the three steps for Quickstart.
      1. Install Xcode and the Xcode Command Line Tools
      2. Agree to Xcode license in Terminal: sudo xcodebuild -license
      3. Install MacPorts for your version of the Mac operating system:
              o macOS Monterey v12
              o macOS Big Sur v11
              o macOS Catalina v10.15
              o macOS Mojave v10.14
              o Older OS? See here.

    Next, install some ports. qt5, ruby31, and python38 are mandatory.
        % sudo port install coreutils
        % sudo port install findutils
        % sudo port install qt5
        % sudo port install ruby31
        % sudo port install python38
        % sudo port install py38-pip

    The main reason you chose this package would be to use KLayout's PYA in Python 3.x.
    The attached file "MacPortsPythonPip.txt" has captured the steps I followed to add some
    Python modules using the "pip-3.8" command on Catalina.
    Please note that the module versions are not up-to-date.


[2] KLayoutPorts.app
    This bundle is for those with the MacPorts environment under /opt/local.
    Optionally, drag and drop this bundle to the /Applications folder, too.
    As the bundle consists of a simple Bash script, you may be able to edit it as you like
    with the help of the "Automator.app" tool.

    The built-in Bash script invokes "/Applications/klayout.app" in the EDITOR mode.
    KLayout's configuration file is "$HOME/.klayout/klayoutrc."
    You can invoke multiple instances of KLayout using this script bundle.

    If you wish to make this package coexist with the standard one (Qt5 Frameworks embedded)
    that uses the OS-bundled Ruby and Python (2.7.x),
      1) Rename "/Applications/klayout.app" to "/Applications/klayout-ports.app"
      2) Edit this script using "Automator.app"
              # myklayout=/Applications/klayout.app (comment out)
              # myconfig=$HOME/.klayout/klayoutrc (comment out)
                |
                |
                V
              myklayout=/Applications/klayout-ports.app
              myconfig=$HOME/.klayout/klayoutrc-ports

[3] KLayoutPorts.app.Bash
    This file is the source Bash script of the "KLayoutPorts.app" bundle.
    You can refer to this script and use the "Automator.app" tool to create your script bundle
    from scratch. See "KLayoutPorts.app.png" image file.

[4] Application Icons
    You can change the application icon of a script bundle using "Finder."
      1) Right-click script bundle "*.app" and "Get info."
      2) Click the default "robot icon" at the top-left, highlighting it.
      3) Drag and drop any icon onto the "robot icon."

[5] KLayout Python Module
    From KLayout 0.27.9, this LW*.dmg contains the KLayout Python Module (pymod)
    compliant with the base Python system.
    Refer to "pymod-pip3-mp38.txt" for more details.

[EOF]
