#-------------------------------------------------------------------------
# File: Anaconda3User-ReadMeFirst.txt
#                              in macbuild/Resources/script-bundle-A.zip
#
# Last modified: 2020-05-23
#-------------------------------------------------------------------------

This folder contains "KLayoutAna3.app" script bundle and some sample icon files.
As the bundle consists of a simple Bash program, you may able to edit it as you like
knowing the following pieces of information.


[1] Anaconda3 setup
    First of all, to use this package, you need to set up the Anaconda3 environment.
    At least, you have to install Ruby package (Qt5 and Python are included from the beginning) :
        % conda install ruby

    The main reason you chose this package would be using KLayout's PYA in Python 3.x.
    You can add different Python modules by the "conda install" command, too.


[2] KLayoutAna3.app: drag and drop this bundle to /Applications folder.
    This bundle is for those who have the Anaconda3 environment under /Applications/anaconda3.
    The standard installation deploys the Anaconda3 under $HOME/opt/anaconda3/.
    Therefore you need to make a symbolic link: /Applications/anaconda3 ---> $HOME/opt/anaconda3/
    The built-in Bash script sets and exports "PYTHONHOME" environment variable, then invokes
    "/Applications/klayout.app" in the EDITOR mode.
    KLayout's configuration file is "$HOME/.klayout/klayoutrc."
    You can invoke multiple instances of KLayout using this script bundle.

    If you wish to make this package coexist with the standard one (Qt5 Frameworks embedded)
    that uses the OS-bundled Ruby and Python (2.7.x),
      1) Rename "/Applications/klayout.app" to "/Applications/klayout-ana3.app"
      2) Edit this script using "Automator.app"
              # myklayout=/Applications/klayout.app (comment out)
              # myconfig=$HOME/.klayout/klayoutrc (comment out)
                |
                |
                V
              myklayout=/Applications/klayout-ana3.app
              myconfig=$HOME/.klayout/klayoutrc-ana3


[3] Application Icons
    You can change the application icon of a script bundle using "Finder."
      1) Right-click a script bundle "*.app" and "Get info."
      2) Click the default "robot icon" at the top-left, then it is highlighted.
      3) Drag and drop any icon onto the "robot icon."

[EOF]
