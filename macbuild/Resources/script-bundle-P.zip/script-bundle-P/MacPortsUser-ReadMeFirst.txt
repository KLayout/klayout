#-------------------------------------------------------------------------
# File: MacPortsUser-ReadMeFirst.txt
#                              in macbuild/Resources/script-bundle-P.zip
#
# Last modified: 2020-06-24
#-------------------------------------------------------------------------

This folder contains the "KLayoutPorts.app" script bundle and some sample icon files.


[1] MacPorts setup
    First of all, to use this package, you need to set up the MacPorts environment.
    Referring to https://www.macports.org/install.php, follow the three steps for Quickstart.
      1. Install Xcode and the Xcode Command Line Tools
      2. Agree to Xcode license in Terminal: sudo xcodebuild -license
      3. Install MacPorts for your version of the Mac operating system:
              o macOS Catalina v10.15
              o macOS Mojave v10.14
              o macOS High Sierra v10.13
              o macOS Sierra v10.12
              o Older OS? See here.

    Next, install some ports. qt5, ruby26, and python37 are mandatory.
        % sudo port install coreutils
        % sudo port install findutils
        % sudo port install qt5
        % sudo port install ruby26
        % sudo port install python37
        % sudo port install py37-pip

    The main reason you chose this package would be to use KLayout's PYA in Python 3.x.
    The attached file "MacPortsPythonPip.txt" has captured the steps I followed to add some
    Python modules using the "pip-3.7" command.


[2] KLayoutPorts.app
    This bundle is for those who have the MacPorts environment under /opt/local.
    Optionally, drag and drop this bundle to /Applications folder, too.
    As the bundle consists of a simple Bash script, you may be able to edit it as you like
    with the help of "Automator.app."

    The built-in Bash script invokes "/Applications/klayout.app" in the EDITOR mode.
    KLayout's configuration file is "$HOME/.klayout/klayoutrc."
    You can invoke multiple instances of KLayout using this script bundle.

    If you wish to make this package coexist with the standard one (Qt5 Frameworks embedded)
    that uses the OS-bundled Ruby and Python (2.7.x),
      1) Rename "/Applications/klayout.app" to "/Applications/klayout-ports.app"
      2) Edit this script using "Automator.app"
              # myklayout=/Applications/klayout.app (comment out)
              # myconfig=$HOME/.klayout/klayoutrc (comment out)
                |
                |
                V
              myklayout=/Applications/klayout-ports.app
              myconfig=$HOME/.klayout/klayoutrc-ports


[3] Application Icons
    You can change the application icon of a script bundle using "Finder."
      1) Right-click a script bundle "*.app" and "Get info."
      2) Click the default "robot icon" at the top-left, then it is highlighted.
      3) Drag and drop any icon onto the "robot icon."

[EOF]
