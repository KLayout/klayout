#-------------------------------------------------------------------------
# File: HomebrewUser-ReadMeFirst.txt
#                              in macbuild/Resources/script-bundle-B.zip
#
# Last modified: 2021-04-29
#-------------------------------------------------------------------------

This folder contains the "KLayoutHomebrew.app" script bundle and some sample icon files.


[1] Homebrew setup
    First of all, to use this package, you need to set up the Homebrew environment.
    Install Homebrew to its preferred prefix (/usr/local for macOS Intel, /opt/homebrew for Apple Silicon).
       Ref. https://github.com/Homebrew/brew/blob/master/docs/Installation.md#alternative-installs.

    At least, you have to install Qt5, Python, and Ruby package:
        % brew install qt5
        % brew install python
        % brew install ruby

    The main reason you chose this package would be to use KLayout's PYA in Python 3.x.
    The attached file "HomebrewPythonPip.txt" has captured the steps I followed to add some
    Python modules using the "pip" command on Catalina.


[2] KLayoutHomebrew.app
    This bundle is for those who have the Homebrew environment under /usr/local/opt/ (for macOS Intel)
    or /opt/homebrew/opt/ (for Apple Silicon).
    Optionally, drag and drop this bundle to /Applications folder, too.
    As the bundle consists of a simple Bash script, you may be able to edit it as you like
    with the help of "Automator.app."

    "KLayoutHomebrew.app" invokes "/Applications/klayout.app" in the EDITOR mode.
    KLayout's configuration file is "$HOME/.klayout/klayoutrc."
    You can invoke multiple instances of KLayout using this script bundle.

    If you wish to make this package coexist with the standard one (Qt5 Frameworks embedded)
    that uses the OS-bundled Ruby and Python (2.7.x),
      1) Rename "/Applications/klayout.app" to "/Applications/klayout-HB.app"
      2) Edit this script using "Automator.app"
              # myklayout=/Applications/klayout.app (comment out)
              # myconfig=$HOME/.klayout/klayoutrc (comment out)
                |
                |
                V
              myklayout=/Applications/klayout-HB.app
              myconfig=$HOME/.klayout/klayoutrc-HB

[3] KLayoutHomebrew.app.Bash
    This is the source Bash script of "KLayoutHomebrew.app."
    You can refer to this script and use the "Automator.app" tool to create your own script bundle
    from scratch. See "KLayoutHomebrew.app.png" image file.

[4] Application Icons
    You can change the application icon of a script bundle using "Finder."
      1) Right-click the script bundle "*.app" and "Get info."
      2) Click the default "robot icon" at the top-left, then it is highlighted.
      3) Drag and drop any icon onto the "robot icon."

[EOF]
